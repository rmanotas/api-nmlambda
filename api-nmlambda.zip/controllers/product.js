// function getProduct (id){}

// function getProducts () {}

// function updateProducts () {}

// function deleteProduct (id) {}

// exports = {
//     getProduct,
//     getProducts,